// Bot The Spot Chile — QR patch (CommonJS)
const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');

const client = new Client({
  authStrategy: new LocalAuth({ dataPath: './.wwebjs_auth' }),
  puppeteer: { args: ['--no-sandbox', '--disable-setuid-sandbox'], headless: true }
});

// === QR handler (mejorado) ===
client.on('qr', (qr) => {
  console.log('====================================================');
  console.log('Escanea este código QR con tu WhatsApp (versión GRANDE):');
  qrcode.generate(qr, { small: false }); // grande para que no se pixelee en logs
  console.log('----------------------------------------------------');
  console.log('Si no puedes escanear el ASCII de arriba, copia y abre este link:');
  console.log(`QR PNG: https://api.qrserver.com/v1/create-qr-code/?size=320x320&data=${encodeURIComponent(qr)}`);
  console.log('====================================================');
});

client.on('ready', () => console.log('✅ Bot de The Spot Chile conectado correctamente.'));

// Resto del código mínimo para dejar el bot arriba (menu simple)
client.on('message', async (msg) => {
  const t = (msg.body||'').trim().toLowerCase();
  if (['hola','menu','menú','buenas','start'].includes(t)) {
    await msg.reply(`👋 ¡Hola! Bienvenido a *The Spot Chile / Botillería Marcet* 🍾
1) Reparto
2) Promociones
3) Apps Delivery`);
  }
});

client.initialize();

# QR Patch
Este parche hace que el evento `qr` muestre:

1) Un **ASCII QR grande** (small:false) — más fácil de escanear en los logs de Render.
2) Un **link PNG clickeable** con el QR: `https://api.qrserver.com/v1/create-qr-code/?data=...`

## Uso
- Reemplaza tu `bot.js` actual por este `bot.js` (o copia solo el manejador `client.on('qr', ...)`).
- Deploy en Render con `npm install` y `npm start`.
- Ve a **Logs** y usa el QR grande o el link PNG.
